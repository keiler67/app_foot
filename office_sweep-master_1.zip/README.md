# office_sweep
A program to use for Office sweepstakes on tournaments such as FIFA World Cup and Rugby World Cups

Two environment variables for testing purposes

SWEEP_LOGIN - to test with a particular user already logged in (saves entering user/password each time to test)
SWEEP_NOW - to fast forward time and test for a particular time

TODO

Test time against french time
Add more colour in other screens similar to pick
Add visualistation google chart to show progress over time
Update admin screen to enter knock-out teams

IMPORTANT

Copy the flags directory in the appdata/public directory of the gas